package com.hcl.doconnect.service;

import java.util.ArrayList;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hcl.doconnect.entities.UserDetails;
import com.hcl.doconnect.repositories.UserRepository;

@Service
public class UserLoginService  implements UserDetailsService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public org.springframework.security.core.userdetails.UserDetails loadUserByUsername(String email)
			throws UsernameNotFoundException {
		Optional<UserDetails> optuser = this.userRepository.findByEmail(email);

		return optuser.map(acc ->{

			User user = new User(acc.getEmail(), 
					acc.getPassword(),
					new ArrayList<>());
			return user;
		})
		.orElseThrow(()-> new UsernameNotFoundException("User does not exist with username "+email));
	}

}
