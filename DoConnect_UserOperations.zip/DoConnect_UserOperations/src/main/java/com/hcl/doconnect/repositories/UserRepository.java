package com.hcl.doconnect.repositories;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.doconnect.entities.UserDetails;

public interface UserRepository extends JpaRepository<UserDetails, Integer> {

	public UserDetails findByEmailAndPassword(String email, String password);

	public Optional<UserDetails> findByEmail(String username);
}
