package com.hcl.doconnect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.doconnect.entities.UserDetails;
import com.hcl.doconnect.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public UserDetails saveUser(UserDetails user) {
		return this.userRepository.save(user);
	}

	public UserDetails loginUser(String email, String password) {
		return userRepository.findByEmailAndPassword(email, password);
	}

	public Object getUserByEmail(String email) {
		
		return userRepository.findByEmail(email);
	}


	
	
	

}
