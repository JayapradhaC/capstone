package com.hcl.doconnect.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.doconnect.entities.AdminDetails;

public interface AdminRepository extends JpaRepository<AdminDetails, Integer> {
	
	public AdminDetails findByEmailAndPassword(String email,String password);
	public boolean existsByEmail(String email);

	
}
