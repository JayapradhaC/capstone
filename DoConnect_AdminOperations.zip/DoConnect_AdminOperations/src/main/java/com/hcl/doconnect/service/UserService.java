package com.hcl.doconnect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.doconnect.entities.UserDetails;
import com.hcl.doconnect.repositories.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepositry;
	public UserDetails saveUser(UserDetails user) {
		return this.userRepositry.save(user);
	}
	public UserDetails loginUser(String email, String password) {
		return userRepositry.findByEmailAndPassword(email, password);
	}
	public boolean deleteUser(UserDetails user) {
		if (this.userRepositry.existsById(user.getUserid())) {
			this.userRepositry.delete(user);
			return true;
		} else {
			return false;
		}
	}
	public UserDetails getUserByEmail(String email) {
		System.out.println("getUserByEmail");
		return this.userRepositry.findByEmail(email);
	}
}