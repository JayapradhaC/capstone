package com.hcl.doconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoConnectAdminOperationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DoConnectAdminOperationsApplication.class, args);
	}

}
