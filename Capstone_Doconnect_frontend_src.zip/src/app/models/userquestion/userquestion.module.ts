export class Userquestion {
  id:number=0;
  title:string="";
  question:string="";
  answer:string="";
 }

