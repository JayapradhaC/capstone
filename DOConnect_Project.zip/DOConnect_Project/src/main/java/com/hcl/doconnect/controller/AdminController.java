package com.hcl.doconnect.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hcl.doconnect.entities.AdminLogin;
import com.hcl.doconnect.entities.UserLogin;
import com.hcl.doconnect.repositories.UserRepository;
import com.hcl.doconnect.service.AdminService;
import com.hcl.doconnect.service.LoginService;

@RestController
@CrossOrigin
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private LoginService loginService;
	
	
	
	@GetMapping("/adminlogin/{email}/{password}")
	public boolean postLogin(@PathVariable String email,@PathVariable String password) {
		AdminLogin user=new AdminLogin();
		user.setEmail(email);
		user.setPassword(password);
		System.out.println(adminService.loginUser(user));
		return adminService.loginUser(user);
	}
	@GetMapping("/userlogin/{email}/{password}")
	public boolean postUserLogin(@PathVariable String email,@PathVariable String password) {
		UserLogin user=new UserLogin();
		user.setEmail(email);
		user.setPassword(password);
		System.out.println("--------------'''"+loginService.userLogin(user));
		return loginService.userLogin(user);
	}
	@PostMapping("/adminregister")
	public String postRegister(@RequestBody AdminLogin user) {
		if(this.adminService.registerData(user)) {
			return "Registered SuccessFully";
		}
		else {
			return "Register Failed";
		}
	}

	
	@Autowired
	public UserRepository userRepository;
	
	
	
	@GetMapping("/admindashboard")
	public List<UserLogin> getAdminUserDashboard() {
		System.out.println(userRepository.findAll());
		return userRepository.findAll();
	}


	
	@DeleteMapping("/deleteuser/{id}")
	public boolean getDeleteUser(@PathVariable int id) {
		return adminService.deleteUser(id);
	}
	
	@GetMapping("/getbyUser/{id}")
	public UserLogin getByUserId(@PathVariable int id) {
		UserLogin user = userRepository.findById(id);
		return user;
	}
	
	@PostMapping("/edituser")
	public boolean postEditUser(@RequestBody UserLogin loginUser) {
		if(adminService.updateUser(loginUser)) {
			return true;
		}
		else {
			return false;
		}
	}
	
	@PostMapping("/adduser")
	public boolean addUser(@RequestBody UserLogin loginUser) {
		return adminService.addUser(loginUser);
	}
}
