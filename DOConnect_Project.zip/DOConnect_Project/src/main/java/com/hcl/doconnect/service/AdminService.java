package com.hcl.doconnect.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.doconnect.entities.AdminLogin;
import com.hcl.doconnect.entities.UserLogin;
import com.hcl.doconnect.repositories.AdminLogRepository;
import com.hcl.doconnect.repositories.UserRepository;

@Service
public class AdminService {
 
	
	
	@Autowired
	private AdminLogRepository adminLogRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	

	
	public boolean loginUser(AdminLogin user) {
		List<AdminLogin> userdetails=adminLogRepository.findAll();
		System.out.println(user);
		for(AdminLogin users:userdetails) {
			if(users.getEmail().equals(user.getEmail())&& users.getPassword().equals(user.getPassword())) {
				return true;
			}
		}
		return false;	
	}
	public boolean registerData(AdminLogin user) {
		this.adminLogRepository.save(user);
		return true;
	}
	
	public boolean addUser(UserLogin user) {
		this.userRepository.save(user);
		return true;
	}
	public boolean deleteUser(int id) {
		this.userRepository.deleteById(id);
		System.out.println("deleted...........");
		return true;
	}
	
	public boolean updateUser(UserLogin loginUser) {
		System.out.println(userRepository.existsById(loginUser.getid()));
		if (this.userRepository.existsById(loginUser.getid())) {
			this.userRepository.save(loginUser);
			return true;
		}
		return false;
	}
	
	
}
