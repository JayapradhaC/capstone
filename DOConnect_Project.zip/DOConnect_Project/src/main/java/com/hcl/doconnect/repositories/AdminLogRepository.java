package com.hcl.doconnect.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.hcl.doconnect.entities.AdminLogin;

public interface AdminLogRepository extends CrudRepository<AdminLogin, Integer>{
	List<AdminLogin> findAll();
}

