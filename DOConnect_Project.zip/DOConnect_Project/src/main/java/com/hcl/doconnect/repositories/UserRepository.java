package com.hcl.doconnect.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.hcl.doconnect.entities.UserLogin;

public interface UserRepository extends CrudRepository<UserLogin, Integer>{
	List<UserLogin> findAll();
	
	UserLogin findByEmail(String email);
	
	UserLogin findById(int id);
	
}
