package com.hcl.doconnect.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hcl.doconnect.entities.UserLogin;
import com.hcl.doconnect.repositories.UserRepository;

@Service
public class LoginService {

	@Autowired
	public UserRepository userRepository;



	public boolean userLogin(UserLogin user) {
		List<UserLogin> userdetails=userRepository.findAll();
		System.out.println(userdetails);
		for(UserLogin users:userdetails) {
			if(users.getEmail().equals(user.getEmail()) && users.getPassword().equals(user.getPassword())) {
				return true;
			}
		}
		return false;	
	}

	public boolean registerData(UserLogin user) {
		this.userRepository.save(user);
		return true;
	}
	
	
	
}
