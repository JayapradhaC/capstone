package com.hcl.AdminCapstone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminCapstoneApplicationTests {

	@Test
	void contextLoads() {
	}

}
